-- Ganapati Club v2 database schema for Supabase/Postgres
-- Run in Supabase Dashboard > SQL Editor.
-- RLS is enabled on every application table. The browser anon key is not a secret;
-- access is controlled by Supabase Auth + these policies.

create extension if not exists pgcrypto;

create table if not exists public.club_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'member' check (role in ('admin','member')),
  created_at timestamptz not null default now()
);

create table if not exists public.club_events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  event_date date not null,
  event_time text not null default '',
  description text not null default '',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.club_notices (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  notice_date date not null default current_date,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.club_members (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  club_role text not null default 'Member'
    check (club_role in ('President','Secretary','Treasurer','Member')),
  phone text not null default '',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.club_donations (
  id uuid primary key default gen_random_uuid(),
  donor_name text not null,
  amount numeric(12,2) not null check (amount > 0),
  payment_method text not null check (payment_method in ('Cash','UPI')),
  note text not null default '',
  donation_date date not null default current_date,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.club_expenses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  amount numeric(12,2) not null check (amount > 0),
  expense_date date not null default current_date,
  note text not null default '',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.club_gallery (
  id uuid primary key default gen_random_uuid(),
  title text not null default '',
  image_url text not null,
  caption text not null default '',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create or replace function public.is_club_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.club_profiles p
    where p.user_id = (select auth.uid()) and p.role = 'admin'
  );
$$;

revoke all on function public.is_club_admin() from public;
grant execute on function public.is_club_admin() to authenticated;

alter table public.club_profiles enable row level security;
alter table public.club_events enable row level security;
alter table public.club_notices enable row level security;
alter table public.club_members enable row level security;
alter table public.club_donations enable row level security;
alter table public.club_expenses enable row level security;
alter table public.club_gallery enable row level security;

-- Profiles: users can see their own profile; admins can see and manage all profiles.
drop policy if exists "profile read own or admin" on public.club_profiles;
create policy "profile read own or admin" on public.club_profiles
for select to authenticated using (user_id = (select auth.uid()) or public.is_club_admin());
drop policy if exists "admin manage profiles" on public.club_profiles;
create policy "admin manage profiles" on public.club_profiles
for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

-- Club content: authenticated users can read events/notices/member directory/gallery.
drop policy if exists "authenticated read events" on public.club_events;
create policy "authenticated read events" on public.club_events for select to authenticated using (true);
drop policy if exists "admin manage events" on public.club_events;
create policy "admin manage events" on public.club_events for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

drop policy if exists "authenticated read notices" on public.club_notices;
create policy "authenticated read notices" on public.club_notices for select to authenticated using (true);
drop policy if exists "admin manage notices" on public.club_notices;
create policy "admin manage notices" on public.club_notices for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

drop policy if exists "authenticated read members" on public.club_members;
create policy "authenticated read members" on public.club_members for select to authenticated using (true);
drop policy if exists "admin manage members" on public.club_members;
create policy "admin manage members" on public.club_members for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

-- Donations and expenses are private to admins by default.
drop policy if exists "admin read donations" on public.club_donations;
create policy "admin read donations" on public.club_donations for select to authenticated using (public.is_club_admin());
drop policy if exists "admin insert donations" on public.club_donations;
create policy "admin insert donations" on public.club_donations for insert to authenticated with check (public.is_club_admin());
drop policy if exists "admin update donations" on public.club_donations;
create policy "admin update donations" on public.club_donations for update to authenticated using (public.is_club_admin()) with check (public.is_club_admin());
drop policy if exists "admin delete donations" on public.club_donations;
create policy "admin delete donations" on public.club_donations for delete to authenticated using (public.is_club_admin());

drop policy if exists "admin manage expenses" on public.club_expenses;
create policy "admin manage expenses" on public.club_expenses for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

-- Gallery is authenticated-read, admin-write. Use private storage buckets if photos are sensitive.
drop policy if exists "authenticated read gallery" on public.club_gallery;
create policy "authenticated read gallery" on public.club_gallery for select to authenticated using (true);
drop policy if exists "admin manage gallery" on public.club_gallery;
create policy "admin manage gallery" on public.club_gallery for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

-- IMPORTANT: do not allow users to self-assign admin. Create the first profile manually
-- using the Dashboard SQL Editor after creating the Auth user:
-- insert into public.club_profiles(user_id, full_name, role)
-- values ('AUTH_USER_UUID_HERE', 'Club Administrator', 'admin');
