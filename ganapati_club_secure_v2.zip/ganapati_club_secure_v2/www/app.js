// Ganapati Club v2 Supabase auth scaffold.
// The current UI still contains local preview data; connect CRUD actions to Supabase
// before handling live records. RLS policies in supabase/schema.sql protect database tables.
const SUPABASE_CONFIG = window.GANAPATI_SUPABASE_CONFIG || {};
const SUPABASE_READY = !!(
  window.supabase && SUPABASE_CONFIG.url &&
  !SUPABASE_CONFIG.url.includes("YOUR_PROJECT_ID") &&
  SUPABASE_CONFIG.anonKey &&
  !SUPABASE_CONFIG.anonKey.includes("YOUR_SUPABASE")
);
const supabaseClient = SUPABASE_READY
  ? window.supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    })
  : null;
(() => {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const STORAGE_KEY = "ganapatiClubDemo.v1";
  let isAdmin = false;
  let lang = "en";
  let pendingItemType = null;
  let toastTimer;

  const translations = {
    en: {
      adminLogin:"Admin Login", welcome:"WELCOME TO OUR COMMUNITY",
      heroTitle:"Together in devotion.<br>Stronger as a community.",
      heroText:"Puja updates, club notices, member information and transparent accounts — all in one place.",
      donateNow:"Donate Now", viewSchedule:"View Puja Schedule", upcomingEvents:"Upcoming events", clubMembers:"Club members",
      recordedDonations:"Recorded donations", pujaSchedule:"Puja Schedule", members:"Members", donations:"Donations",
      accounts:"Income & Expenses", gallery:"Photo Gallery", noticeBoard:"Notice Board", communityCalendar:"COMMUNITY CALENDAR",
      addEvent:"+ Add event", stayUpdated:"STAY UPDATED", addNotice:"+ Add notice", ourPeople:"OUR PEOPLE",
      addMember:"+ Add member", memberName:"Name", role:"Role", memberPhone:"Phone",
      memberPrivacy:"Member details should only be entered by authorized club administrators.", supportTheClub:"SUPPORT THE CLUB",
      donorName:"Donor name", amount:"Amount (₹)", paymentMethod:"Payment method", note:"Note (optional)",
      recordDonation:"Record donation", recentDonations:"Recent donations", demoStorage:"Demo data is stored on this device",
      onlinePaymentSetup:"Online UPI setup", upiHelp:"This starter records UPI donations but does not collect money. Add your verified UPI ID or a trusted payment gateway before accepting online payments.",
      transparentRecords:"TRANSPARENT RECORDS", addExpense:"+ Add expense", totalIncome:"Total income", totalExpenses:"Total expenses",
      balance:"Balance", exportData:"Export records (CSV)", memories:"MEMORIES", pujaMoments:"Puja moments", decoration:"Decorations",
      communityEvents:"Community events", galleryHelp:"Gallery tiles are placeholders. Connect a secure image upload/storage service to publish real photos.",
      footerText:"Built with devotion, service and community spirit.", demoLoginHelp:"Demo only: default demo password is Ganapati@123. Do not use this login for a public deployment.",
      adminPassword:"Admin password", signIn:"Sign in", save:"Save", logout:"Log out", loginSuccess:"Admin mode enabled",
      loginFail:"Incorrect demo password.", loggedOut:"Admin mode disabled.", addEventTitle:"Add puja event", addNoticeTitle:"Add notice",
      addMemberTitle:"Add member", addExpenseTitle:"Add expense", eventTitle:"Event title", date:"Date", time:"Time",
      description:"Description", noticeTitle:"Notice title", memberNameField:"Member name", memberRole:"Role",
      phone:"Phone number", expenseTitle:"Expense description", expenseAmount:"Amount (₹)", noEvents:"No events added yet.",
      noNotices:"No notices yet.", noMembers:"No members added yet.", noDonations:"No donations recorded yet.", noExpenses:"No expenses recorded yet.",
      saved:"Saved successfully.", deleted:"Removed.", exported:"CSV export prepared.", donationRecorded:"Donation recorded on this device.",
      rolePresident:"President", roleSecretary:"Secretary", roleTreasurer:"Treasurer", roleMember:"Member",
      methodCash:"Cash", methodUPI:"UPI", statusAdmin:"Admin", signInFirst:"Admin login required for that action.",
      amountError:"Enter a valid positive amount.", dateLabel:"Date", expense:"Expense", event:"Event", notice:"Notice"
    },
    or: {
      adminLogin:"ଆଡମିନ୍ ଲଗଇନ୍", welcome:"ଆମ ସମ୍ପ୍ରଦାୟକୁ ସ୍ୱାଗତ",
      heroTitle:"ଭକ୍ତିରେ ଏକତା।<br>ସମ୍ପ୍ରଦାୟରେ ଶକ୍ତି।",
      heroText:"ପୂଜା ସୂଚନା, କ୍ଲବ୍ ନୋଟିସ୍, ସଦସ୍ୟ ବିବରଣୀ ଏବଂ ହିସାବ — ସବୁ ଗୋଟିଏ ସ୍ଥାନରେ।",
      donateNow:"ଦାନ କରନ୍ତୁ", viewSchedule:"ପୂଜା ସୂଚୀ ଦେଖନ୍ତୁ", upcomingEvents:"ଆଗାମୀ କାର୍ଯ୍ୟକ୍ରମ", clubMembers:"କ୍ଲବ୍ ସଦସ୍ୟ",
      recordedDonations:"ମୋଟ ଦାନ", pujaSchedule:"ପୂଜା ସୂଚୀ", members:"ସଦସ୍ୟ", donations:"ଦାନ",
      accounts:"ଆୟ ଓ ବ୍ୟୟ", gallery:"ଫଟୋ ଗ୍ୟାଲେରୀ", noticeBoard:"ସୂଚନା ଫଳକ", communityCalendar:"କ୍ଲବ୍ କ୍ୟାଲେଣ୍ଡର",
      addEvent:"+ କାର୍ଯ୍ୟକ୍ରମ ଯୋଡ଼ନ୍ତୁ", stayUpdated:"ନୂତନ ସୂଚନା", addNotice:"+ ସୂଚନା ଯୋଡ଼ନ୍ତୁ", ourPeople:"ଆମ ସଦସ୍ୟ",
      addMember:"+ ସଦସ୍ୟ ଯୋଡ଼ନ୍ତୁ", memberName:"ନାମ", role:"ପଦବୀ", memberPhone:"ଫୋନ୍",
      memberPrivacy:"ସଦସ୍ୟଙ୍କ ବିବରଣୀ କେବଳ ଅନୁମୋଦିତ ଆଡମିନ୍ ଯୋଡ଼ିବା ଉଚିତ।", supportTheClub:"କ୍ଲବ୍‌କୁ ସହଯୋଗ କରନ୍ତୁ",
      donorName:"ଦାତାଙ୍କ ନାମ", amount:"ରାଶି (₹)", paymentMethod:"ଦେୟ ପ୍ରକାର", note:"ଟିପ୍ପଣୀ (ଇଚ୍ଛାଧୀନ)",
      recordDonation:"ଦାନ ଲେଖନ୍ତୁ", recentDonations:"ସାମ୍ପ୍ରତିକ ଦାନ", demoStorage:"ଡେମୋ ତଥ୍ୟ ଏହି ଡିଭାଇସ୍‌ରେ ସଂରକ୍ଷିତ",
      onlinePaymentSetup:"ଅନଲାଇନ୍ UPI ସେଟଅପ୍", upiHelp:"ଏହି ଆପ୍ ଡେମୋ UPI ଦାନ ରେକର୍ଡ କରେ, କିନ୍ତୁ ଟଙ୍କା ଗ୍ରହଣ କରେ ନାହିଁ। ଅନଲାଇନ୍ ଦେୟ ପୂର୍ବରୁ ଯାଞ୍ଚିତ UPI ID କିମ୍ବା ବିଶ୍ୱସନୀୟ ପେମେଣ୍ଟ ଗେଟୱେ ଯୋଡ଼ନ୍ତୁ।",
      transparentRecords:"ସ୍ୱଚ୍ଛ ହିସାବ", addExpense:"+ ଖର୍ଚ୍ଚ ଯୋଡ଼ନ୍ତୁ", totalIncome:"ମୋଟ ଆୟ", totalExpenses:"ମୋଟ ଖର୍ଚ୍ଚ",
      balance:"ବଳକା", exportData:"ହିସାବ ରପ୍ତାନି (CSV)", memories:"ସ୍ମୃତି", pujaMoments:"ପୂଜାର ମୁହୂର୍ତ୍ତ", decoration:"ସାଜସଜ୍ଜା",
      communityEvents:"ସାମୂହିକ କାର୍ଯ୍ୟକ୍ରମ", galleryHelp:"ଏଗୁଡ଼ିକ ନମୁନା ଟାଇଲ୍। ପ୍ରକୃତ ଫଟୋ ପାଇଁ ସୁରକ୍ଷିତ ଅପଲୋଡ୍ ସେବା ଯୋଡ଼ନ୍ତୁ।",
      footerText:"ଭକ୍ତି, ସେବା ଓ ସମ୍ପ୍ରଦାୟ ଭାବନାରେ ନିର୍ମିତ।", demoLoginHelp:"କେବଳ ଡେମୋ: ଡିଫଲ୍ଟ ପାସୱାର୍ଡ Ganapati@123। ସାର୍ବଜନୀନ ଆପ୍‌ରେ ଏହା ବ୍ୟବହାର କରନ୍ତୁ ନାହିଁ।",
      adminPassword:"ଆଡମିନ୍ ପାସୱାର୍ଡ", signIn:"ଲଗଇନ୍", save:"ସଂରକ୍ଷଣ", logout:"ଲଗଆଉଟ୍", loginSuccess:"ଆଡମିନ୍ ମୋଡ୍ ଚାଲୁ",
      loginFail:"ପାସୱାର୍ଡ ଭୁଲ।", loggedOut:"ଆଡମିନ୍ ମୋଡ୍ ବନ୍ଦ।", addEventTitle:"ପୂଜା କାର୍ଯ୍ୟକ୍ରମ ଯୋଡ଼ନ୍ତୁ", addNoticeTitle:"ସୂଚନା ଯୋଡ଼ନ୍ତୁ",
      addMemberTitle:"ସଦସ୍ୟ ଯୋଡ଼ନ୍ତୁ", addExpenseTitle:"ଖର୍ଚ୍ଚ ଯୋଡ଼ନ୍ତୁ", eventTitle:"କାର୍ଯ୍ୟକ୍ରମ ନାମ", date:"ତାରିଖ", time:"ସମୟ",
      description:"ବିବରଣୀ", noticeTitle:"ସୂଚନା ଶୀର୍ଷକ", memberNameField:"ସଦସ୍ୟଙ୍କ ନାମ", memberRole:"ପଦବୀ",
      phone:"ଫୋନ୍ ନମ୍ବର", expenseTitle:"ଖର୍ଚ୍ଚ ବିବରଣୀ", expenseAmount:"ରାଶି (₹)", noEvents:"ଏପର୍ଯ୍ୟନ୍ତ କାର୍ଯ୍ୟକ୍ରମ ନାହିଁ।",
      noNotices:"ଏପର୍ଯ୍ୟନ୍ତ ସୂଚନା ନାହିଁ।", noMembers:"ଏପର୍ଯ୍ୟନ୍ତ ସଦସ୍ୟ ନାହାନ୍ତି।", noDonations:"ଏପର୍ଯ୍ୟନ୍ତ ଦାନ ରେକର୍ଡ ନାହିଁ।", noExpenses:"ଏପର୍ଯ୍ୟନ୍ତ ଖର୍ଚ୍ଚ ନାହିଁ।",
      rolePresident:"ସଭାପତି", roleSecretary:"ସମ୍ପାଦକ", roleTreasurer:"କୋଷାଧ୍ୟକ୍ଷ", roleMember:"ସଦସ୍ୟ",
      methodCash:"ନଗଦ", methodUPI:"UPI", statusAdmin:"ଆଡମିନ୍", signInFirst:"ଏହି କାର୍ଯ୍ୟ ପାଇଁ ଆଡମିନ୍ ଲଗଇନ୍ ଆବଶ୍ୟକ।",
      amountError:"ଠିକ୍ ଧନାତ୍ମକ ରାଶି ଲେଖନ୍ତୁ।", dateLabel:"ତାରିଖ", expense:"ଖର୍ଚ୍ଚ", event:"କାର୍ଯ୍ୟକ୍ରମ", notice:"ସୂଚନା"
    }
  };
  const seed = {
    events: [
      {id:1,title:"Weekly Ganesh Puja",date:todayPlus(2),time:"06:30 PM",description:"Puja, aarti and prasad distribution."},
      {id:2,title:"Club Members Meeting",date:todayPlus(7),time:"05:00 PM",description:"Planning, volunteering and club updates."}
    ],
    notices: [{id:3,title:"Welcome to Ganapati Club",description:"Members can check upcoming programs and keep donation records up to date.",date:todayISO()}],
    members: [
      {id:4,name:"Club President",role:"President",phone:""},
      {id:5,name:"Club Secretary",role:"Secretary",phone:""},
      {id:6,name:"Club Treasurer",role:"Treasurer",phone:""}
    ],
    donations: [], expenses: []
  };
  function todayISO(){ return new Date().toISOString().slice(0,10); }
  function todayPlus(days){ const d=new Date(); d.setDate(d.getDate()+days); return d.toISOString().slice(0,10); }
  function loadData(){
    try { const saved=localStorage.getItem(STORAGE_KEY); if(saved){ const parsed=JSON.parse(saved); return {...structuredClone(seed),...parsed}; } } catch(e){ console.warn("Unable to read local data",e); }
    return structuredClone(seed);
  }
  let data=loadData();
  function persist(){ try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data));}catch(e){showToast("Storage unavailable. Export your records.");} }
  function t(key){return (translations[lang]&&translations[lang][key])||translations.en[key]||key;}
  function escapeHTML(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function money(n){return new Intl.NumberFormat(lang==="or"?"en-IN":"en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(Number(n)||0);}
  function fmtDate(date){if(!date)return "";const d=new Date(date+"T00:00:00");return d.toLocaleDateString(lang==="or"?"or-IN":"en-IN",{day:"2-digit",month:"short",year:"numeric"});}
  function showToast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600);}
  function setBackendStatus(message){const el=$("#backendStatus");if(el)el.textContent=message;}
  if(!SUPABASE_READY){
    setBackendStatus("Supabase not configured. Add your project URL and public key, run supabase/schema.sql, then sign in. Current content is local preview data only.");
  } else {
    setBackendStatus("Supabase configuration found. Sign in to verify your account. Content panels are still local preview data until CRUD integration is completed.");
  }
  function empty(text){return `<p class="muted">${escapeHTML(text)}</p>`;}
  function render(){
    $("#eventCount").textContent=data.events.filter(e=>e.date>=todayISO()).length;
    $("#memberCount").textContent=data.members.length;
    $("#donationTotal").textContent=money(data.donations.reduce((s,d)=>s+Number(d.amount||0),0));
    $("#incomeTotal").textContent=money(data.donations.reduce((s,d)=>s+Number(d.amount||0),0));
    $("#expenseTotal").textContent=money(data.expenses.reduce((s,e)=>s+Number(e.amount||0),0));
    $("#balanceTotal").textContent=money(data.donations.reduce((s,d)=>s+Number(d.amount||0),0)-data.expenses.reduce((s,e)=>s+Number(e.amount||0),0));
    $("#eventList").innerHTML=data.events.length?data.events.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(e=>`<article class="event-item"><div class="date-box"><strong>${escapeHTML(e.date.slice(8,10))}</strong><span>${escapeHTML(new Date(e.date+"T00:00:00").toLocaleDateString("en",{month:"short"}))}</span></div><div class="item-main"><strong>${escapeHTML(e.title)}</strong><p>🕒 ${escapeHTML(e.time||"")} · ${escapeHTML(fmtDate(e.date))}</p><p>${escapeHTML(e.description||"")}</p>${isAdmin?`<button class="text-btn" data-delete="events" data-id="${e.id}">Remove</button>`:""}</div></article>`).join(""):empty(t("noEvents"));
    $("#noticeList").innerHTML=data.notices.length?data.notices.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(n=>`<article class="notice-item"><span class="notice-symbol">📌</span><div class="item-main"><strong>${escapeHTML(n.title)}</strong><p>${escapeHTML(n.description||"")}</p><span class="pill">${escapeHTML(fmtDate(n.date))}</span>${isAdmin?`<button class="text-btn" data-delete="notices" data-id="${n.id}">Remove</button>`:""}</div></article>`).join(""):empty(t("noNotices"));
    $("#memberTable").innerHTML=data.members.length?data.members.map(m=>`<tr><td>${escapeHTML(m.name)}</td><td>${escapeHTML(roleLabel(m.role))}</td><td>${escapeHTML(m.phone||"—")}${isAdmin?` <button class="text-btn" data-delete="members" data-id="${m.id}" aria-label="Remove member">×</button>`:""}</td></tr>`).join(""):`<tr><td colspan="3">${escapeHTML(t("noMembers"))}</td></tr>`;
    $("#donationList").innerHTML=data.donations.length?data.donations.slice().reverse().slice(0,8).map(d=>`<article class="donation-item"><div class="item-main"><strong>${escapeHTML(d.donor)}</strong><p>${escapeHTML(d.method==="UPI"?t("methodUPI"):t("methodCash"))} · ${escapeHTML(fmtDate(d.date))}${d.note?" · "+escapeHTML(d.note):""}</p></div><span class="amount">${money(d.amount)}</span></article>`).join(""):empty(t("noDonations"));
    $("#expenseList").innerHTML=data.expenses.length?data.expenses.slice().reverse().slice(0,8).map(e=>`<article class="expense-item"><div class="item-main"><strong>${escapeHTML(e.title)}</strong><p>${escapeHTML(fmtDate(e.date))}</p>${isAdmin?`<button class="text-btn" data-delete="expenses" data-id="${e.id}">Remove</button>`:""}</div><span class="amount" style="color:#a52a20">−${money(e.amount)}</span></article>`).join(""):empty(t("noExpenses"));
    document.body.classList.toggle("is-admin",isAdmin);
    $("#loginButton").textContent=isAdmin?t("logout"):t("adminLogin");
  }
  function roleLabel(role){const map={President:"rolePresident",Secretary:"roleSecretary",Treasurer:"roleTreasurer",Member:"roleMember"};return t(map[role]||"roleMember");}
  function applyLanguage(){
    document.documentElement.lang=lang==="or"?"or":"en";
    document.querySelectorAll("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(translations[lang][key])el.innerHTML=translations[lang][key];});
    $("#languageToggle").textContent=lang==="en"?"ଓଡ଼ିଆ":"English";
    render();
  }
  function requireAdmin(){if(!isAdmin){showToast(t("signInFirst"));return false;}return true;}
  function openItemDialog(type){
    if(!requireAdmin())return;
    pendingItemType=type;
    const configs={
      event:{title:"addEventTitle",fields:[["title","eventTitle","text",true],["date","date","date",true],["time","time","text",false],["description","description","text",false]]},
      notice:{title:"addNoticeTitle",fields:[["title","noticeTitle","text",true],["date","date","date",true],["description","description","text",true]]},
      member:{title:"addMemberTitle",fields:[["name","memberNameField","text",true],["role","memberRole","select",true],["phone","phone","tel",false]]},
      expense:{title:"addExpenseTitle",fields:[["title","expenseTitle","text",true],["amount","expenseAmount","number",true],["date","date","date",true]]}
    };
    const cfg=configs[type];$("#itemDialogTitle").textContent=t(cfg.title);
    $("#itemFields").innerHTML=cfg.fields.map(([name,label,type,required])=>{
      let control=type==="select"?`<select name="${name}"><option value="President">${escapeHTML(t("rolePresident"))}</option><option value="Secretary">${escapeHTML(t("roleSecretary"))}</option><option value="Treasurer">${escapeHTML(t("roleTreasurer"))}</option><option value="Member">${escapeHTML(t("roleMember"))}</option></select>`:`<input name="${name}" type="${type}" ${type==="number"?'min="1" max="10000000" step="1"':""} ${required?"required":""} ${name==="date"?`value="${todayISO()}"`:""} maxlength="${type==="text"?180:undefined}">`;
      return `<label><span>${escapeHTML(t(label))}</span>${control}</label>`;
    }).join("");
    $("#itemDialog").showModal();
  }
  $("#languageToggle").addEventListener("click",()=>{lang=lang==="en"?"or":"en";applyLanguage();});
  $("#loginButton").addEventListener("click", async ()=>{
    if(supabaseClient){
      const { data: { session } } = await supabaseClient.auth.getSession();
      if(session){ await supabaseClient.auth.signOut(); isAdmin=false; render(); setBackendStatus("Signed out. Local preview data is separate from the database."); showToast(t("loggedOut")); return; }
    } else if(isAdmin){isAdmin=false;render();showToast(t("loggedOut"));return;}
    $("#loginError").hidden=true;$("#adminPassword").value="";
    if($("#authEmail")) $("#authEmail").value="";
    $("#loginDialog").showModal();
  });
  $("#loginForm").addEventListener("submit",async e=>{
    e.preventDefault();
    if(!supabaseClient){
      $("#loginError").textContent="Supabase is not configured. Add your project URL and public anon/publishable key, then refresh.";
      $("#loginError").hidden=false; return;
    }
    const email=$("#authEmail").value.trim(), password=$("#adminPassword").value;
    const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});
    if(error){$("#loginError").textContent=error.message;$("#loginError").hidden=false;return;}
    const {data:profile,error:profileError}=await supabaseClient.from("club_profiles").select("role,full_name").eq("user_id",data.user.id).single();
    if(profileError || !profile){
      await supabaseClient.auth.signOut();
      $("#loginError").textContent="Login succeeded, but no club profile exists. Ask the club admin to create your profile.";
      $("#loginError").hidden=false;return;
    }
    isAdmin=profile.role==="admin";
    $("#loginDialog").close();render();
    setBackendStatus("Connected to Supabase as "+(profile.full_name||data.user.email)+" ("+profile.role+"). The current content panels are still in local preview mode until CRUD integration is completed.");
    showToast(isAdmin?t("loginSuccess"):"Member login successful");
  });
  $("#addEventButton").addEventListener("click",()=>openItemDialog("event"));
  $("#addNoticeButton").addEventListener("click",()=>openItemDialog("notice"));
  $("#addMemberButton").addEventListener("click",()=>openItemDialog("member"));
  $("#addExpenseButton").addEventListener("click",()=>openItemDialog("expense"));
  $("#itemForm").addEventListener("submit",e=>{
    e.preventDefault();if(!requireAdmin())return;
    const values=Object.fromEntries(new FormData(e.currentTarget).entries());const id=Date.now();
    if(pendingItemType==="event")data.events.push({id,title:values.title.trim(),date:values.date,time:values.time||"",description:values.description||""});
    if(pendingItemType==="notice")data.notices.push({id,title:values.title.trim(),date:values.date,description:values.description.trim()});
    if(pendingItemType==="member")data.members.push({id,name:values.name.trim(),role:values.role,phone:values.phone.trim()});
    if(pendingItemType==="expense"){const amount=Number(values.amount);if(!Number.isFinite(amount)||amount<=0){showToast(t("amountError"));return;}data.expenses.push({id,title:values.title.trim(),date:values.date,amount});}
    persist();render();$("#itemDialog").close();showToast(t("saved"));
  });
  document.addEventListener("click",e=>{
    const btn=e.target.closest("[data-delete]");if(!btn)return;
    if(!requireAdmin())return;
    const collection=btn.dataset.delete,id=Number(btn.dataset.id);
    if(!["events","notices","members","expenses"].includes(collection))return;
    data[collection]=data[collection].filter(x=>x.id!==id);persist();render();showToast(t("deleted"));
  });
  $("#donationForm").addEventListener("submit",e=>{
    e.preventDefault();const form=e.currentTarget;const values=Object.fromEntries(new FormData(form).entries());const amount=Number(values.amount);
    if(!Number.isFinite(amount)||amount<=0){showToast(t("amountError"));return;}
    data.donations.push({id:Date.now(),donor:values.donor.trim(),amount,method:values.method,note:(values.note||"").trim(),date:todayISO()});
    persist();render();form.reset();showToast(t("donationRecorded"));
  });
  $("#exportButton").addEventListener("click",()=>{
    if(!requireAdmin())return;
    const rows=[["Type","Name/Description","Date","Amount","Method","Note"]];
    data.donations.forEach(d=>rows.push(["Donation",d.donor,d.date,d.amount,d.method,d.note||""]));
    data.expenses.forEach(x=>rows.push(["Expense",x.title,x.date,-Number(x.amount),"",""]));
    const csv=rows.map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="ganapati-club-accounts.csv";a.click();URL.revokeObjectURL(url);showToast(t("exported"));
  });
  $("#year").textContent=new Date().getFullYear();
  applyLanguage();
  if(supabaseClient){
    supabaseClient.auth.getSession().then(async ({data:{session}})=>{
      if(!session)return;
      const {data:profile,error}=await supabaseClient.from("club_profiles").select("role,full_name").eq("user_id",session.user.id).single();
      if(!error && profile){isAdmin=profile.role==="admin";render();setBackendStatus("Signed in as "+(profile.full_name||session.user.email)+" ("+profile.role+"). Current panels still use local preview data.");}
    });
  }
  if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
})();
