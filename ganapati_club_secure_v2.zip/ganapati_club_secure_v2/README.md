# Ganapati Club v2 — Secure Login + Shared Database

This version extends the HTML/CSS/JavaScript starter with a Supabase Auth + PostgreSQL database setup. The UI is still a starter; configure the backend and test the RLS policies before using real member or financial data.

## Included in v2
- Supabase email/password authentication integration scaffold
- PostgreSQL schema for profiles, puja events, notices, members, donations, expenses and gallery metadata
- Row Level Security (RLS) policies
- Admin/member roles stored in `club_profiles`
- Traditional red-and-gold design and Odia/English UI from v1
- Capacitor configuration for a future Android APK build

## A key security difference
The old demo password/localStorage mode is **not suitable for real use**. Version 2 is designed for Supabase authentication and server-enforced RLS. The browser must never contain a Supabase `service_role` key. Only the project's public anon/publishable key belongs in client config.

## 1. Create the Supabase backend
1. Create a project at https://supabase.com/.
2. In Project Settings / API, copy the Project URL and the publishable key (or legacy anon key).
3. Open **SQL Editor** and run the complete `supabase/schema.sql` file.
4. In **Authentication > Providers**, enable Email. For a real launch, keep email confirmation enabled and configure SMTP so club members can verify their email.
5. In **Authentication > URL Configuration**, set your website's Site URL and allowed redirect URLs.
6. Create the first admin account in Authentication > Users, using a real club-admin email.
7. Copy that account's user UUID, then run this SQL in the SQL Editor, replacing the example values:

```sql
insert into public.club_profiles (user_id, full_name, role)
values ('PASTE_AUTH_USER_UUID_HERE', 'Club Administrator', 'admin')
on conflict (user_id) do update
set full_name = excluded.full_name, role = 'admin';
```

Do not give admin role to users through a public sign-up form. Only a trusted project owner should promote accounts.

## 2. Configure the frontend
The browser configuration is public by design; RLS is what protects data.

1. Open `www/app.js`.
2. Find `SUPABASE CONFIG` near the top.
3. Replace `https://YOUR_PROJECT_ID.supabase.co` and `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY` with your project values.
4. Do **not** put a service role/secret key in `www/`, in Android assets, or in source control.
5. Host the site over HTTPS, or run locally with a local web server.

> Note: the provided existing v1 UI remains available as a local preview. The database schema and secure login are the backend foundation; finish the table-to-UI integration before using the app for live records. Until Supabase is configured, use only sample/demo data.

## 3. Run the website
From the project folder:

```bash
npm install
python -m http.server 8080 --directory www
```

Open `http://localhost:8080`.

## 4. Build Android
Install Node.js LTS and Android Studio, then run:

```bash
npm run android:add
npm run android:sync
npm run android:open
```

In Android Studio, wait for Gradle sync and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. This produces an installable test APK. Use a signed release build for distribution.

## 5. Production checklist
- Replace the remaining localStorage-based demo UI actions with Supabase CRUD calls for every table before live use.
- Use only the public Supabase key in the client; never ship a service role key.
- Test RLS with a member account and an admin account, including direct API requests.
- Donations and expenses are admin-only in the included schema. Decide whether members should be able to submit donation pledges separately.
- UPI payment entries do not collect or verify payments. Use a trusted gateway and server-side webhook verification if online payments are needed.
- Add rate limits, audit logs, backups, recovery procedures and privacy policy/consent for member information.
- Consider private photo storage and signed URLs for club gallery images.
