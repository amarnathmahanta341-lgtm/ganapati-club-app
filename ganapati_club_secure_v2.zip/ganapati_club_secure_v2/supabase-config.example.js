// Copy the values into www/app.js CONFIG below.
// The Supabase anon/publishable key is intended for client use only.
// NEVER put a service_role/secret key in website or Android code.
window.GANAPATI_SUPABASE_CONFIG = {
  url: "https://YOUR_PROJECT_ID.supabase.co",
  anonKey: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
